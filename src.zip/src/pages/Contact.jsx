import React from 'react'
import './Contact.css'

function Contact() {
  return (
    <div className='Contact'></div>
  )
}

export default Contact