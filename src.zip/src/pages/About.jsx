import React from 'react'
import './About.css'

function About() {
  return (
    <div className='About'></div>
  )
}

export default About